const settings = {
  packname: '𝒅𝒂𝒏𝒊𝒆𝒍 - 𝒑𝒂𝒓𝒌',
  author: '‎',
  botName: ".⤹𝐌𝐎𝐑𝐄𝐍𝐎⤾.",
  botOwner: '𝐌𝐎𝐑𝐄𝐍𝐎', // Your name
  ownerNumber: '212689616601', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "3.0.4",
  updateZipUrl: "https://github.com/mruniquehacker/Knightbot-MD/archive/refs/heads/main.zip",
};

module.exports = settings;
